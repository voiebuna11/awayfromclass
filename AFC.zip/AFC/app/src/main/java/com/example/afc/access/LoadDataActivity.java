package com.example.afc.access;

import android.content.Intent;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.widget.Toast;

import com.android.volley.RequestQueue;
import com.android.volley.toolbox.Volley;
import com.example.afc.MainActivity;
import com.example.afc.R;
import com.example.afc.classes.SessionManagement;

public class LoadDataActivity extends AppCompatActivity {
    private RequestQueue mQueue;
    private SessionManagement session;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_load_data);

        session = new SessionManagement(getApplicationContext());
        mQueue =  Volley.newRequestQueue(getApplicationContext());
        session.setAFCLink("https://32dc45ba.ngrok.io");
        //getAFCConnectionLink();
        //goToMain();
    }
    /*
    public void getAFCConnectionLink() {
        String url = "http://www.maravet.com/androidshop/test.php";
        StringRequest request = new StringRequest(Request.Method.POST, url, new Response.Listener<String>() {
            @Override
            public void onResponse(String response) {
                try {
                    JSONObject j = new JSONObject(response); //response este raspunsul .. J json <- raspuns
                    JSONArray jsonArray = j.getJSONArray("data"); //j este obiectul json raspuns

                    String link = "not_found";
                    for (int i = 0; i < jsonArray.length(); i++) {
                        JSONObject intermediar = jsonArray.getJSONObject(i);
                        link = intermediar.getString("link");
                    }
                    session.setAFCLink(link);
                } catch (JSONException e) {
                    e.printStackTrace();
                }
            }
        }, new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError error) {
                error.printStackTrace();
            }
        }) {
            @Override
            protected Map<String, String> getParams() throws AuthFailureError {

                Map<String, String> params = new HashMap<>();
                params.put("link", "1"); //parametrii POST
                return params;
            }
        };
        mQueue.add(request);
    }
    */
    private void goToMain(){
        // redirect  to Main Activity
        Intent i = new Intent(getApplicationContext(), MainActivity.class);
        // Closing all the Activities
        i.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TASK);
        // Staring Activity
        getApplicationContext().startActivity(i);
    }

    private void alert(String text){
        Toast.makeText(getApplicationContext(), text, Toast.LENGTH_SHORT).show();
    }
}
