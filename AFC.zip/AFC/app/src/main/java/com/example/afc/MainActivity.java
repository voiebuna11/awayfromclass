package com.example.afc;

import android.os.Bundle;
import android.view.View;

import com.android.volley.RequestQueue;
import com.android.volley.toolbox.Volley;

public class MainActivity extends BaseActivity {
    RequestQueue mQueue;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        mQueue =  Volley.newRequestQueue(getApplicationContext());

        stopLoadingBar();
    }

    public void goToEmpty(View view){
        alert(sessionData.get("us_id"));
    }

    @Override
    public int getLayoutResource() {
        return R.layout.activity_main;
    }
}
