package com.example.afc.classes;

import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.support.v7.app.AlertDialog;

import com.example.afc.MainActivity;
import com.example.afc.access.LoginActivity;

import java.util.HashMap;
import java.util.Timer;

public class SessionManagement {
    Timer internetChecker;
    AlertDialog.Builder noInternetDialog;
    // Shared Preferences
    SharedPreferences pref;
    // Editor for Shared preferences
    SharedPreferences.Editor editor;
    // Context
    Context _context;
    // Shared pref mode
    int PRIVATE_MODE = 0;

    // Sharedpref file name
    private static final String PREF_NAME = "AFCPref";

    // All Shared Preferences Keys
    private static final String IS_LOGIN = "IsLoggedIn";

    // User name (make variable public to access from outside)
    private static final String KEY_USER = "us_user";
    private static final String KEY_EMAIL = "us_email";
    private static final String KEY_ID = "us_id";
    private static final String KEY_LINK = "us_link";
    private static final String KEY_TYPE = "us_type";
    private static final String KEY_FNAME = "us_first_name";
    private static final String KEY_LNAME = "us_last_name";
    private static final String KEY_PHONE = "us_phone";
    private static final String KEY_CITY = "us_city";
    private static final String KEY_YEAR = "us_year";
    private static final String KEY_SPEC = "us_spec";

    // Constructor
    public SessionManagement(Context context) {
        this._context = context;
        pref = _context.getSharedPreferences(PREF_NAME, PRIVATE_MODE);
        editor = pref.edit();
    }

    public void createSession(String id, String type, String user, String email, String fname, String lname, String phone, String city,
                                   String year, String spec){
        // Storing login value as TRUE
        editor.putBoolean(IS_LOGIN, true);

        // Storing name in pref
        editor.putString(KEY_ID, id);
        editor.putString(KEY_TYPE, type);
        editor.putString(KEY_USER, user);
        editor.putString(KEY_EMAIL, email);
        editor.putString(KEY_FNAME, fname);
        editor.putString(KEY_LNAME, lname);
        editor.putString(KEY_PHONE, phone);
        editor.putString(KEY_CITY, city);
        editor.putString(KEY_YEAR, year);
        editor.putString(KEY_SPEC, spec);

        // commit changes
        editor.commit();
    }

    public void setAFCLink(String link){
        editor.putString(KEY_LINK, link);
        editor.commit();
        goToMain();
    }

    public String getAFCLink(){
        return pref.getString(KEY_LINK, null);

    }

    public HashMap<String, String> getUserDetails(){
        HashMap<String, String> user = new HashMap<String, String>();

        user.put(KEY_ID, pref.getString(KEY_ID, null));
        user.put(KEY_TYPE, pref.getString(KEY_TYPE, null));
        user.put(KEY_USER, pref.getString(KEY_USER, null));
        user.put(KEY_EMAIL, pref.getString(KEY_EMAIL, null));
        user.put(KEY_FNAME, pref.getString(KEY_FNAME, null));
        user.put(KEY_LNAME, pref.getString(KEY_LNAME, null));
        user.put(KEY_PHONE, pref.getString(KEY_PHONE, null));
        user.put(KEY_CITY, pref.getString(KEY_CITY, null));
        user.put(KEY_YEAR, pref.getString(KEY_YEAR, null));
        user.put(KEY_SPEC, pref.getString(KEY_SPEC, null));
        // return user
        return user;
    }

    public void checkLogin(){
        // Check login status
        if(!this.isLoggedIn()){
            // user is not logged in redirect him to Login Activity
            Intent i = new Intent(_context, LoginActivity.class);
            // Closing all the Activities
            i.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TASK);
            // Staring Activity
            _context.startActivity(i);
        }
    }

    public void logoutUser(){
        // Clearing all data from Shared Preferences
        editor.clear();
        editor.commit();

        Intent i = new Intent(_context, LoginActivity.class);
        i.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TASK);
        _context.startActivity(i);
    }

    public boolean isLoggedIn(){
        HashMap<String, String> user = getUserDetails();
        String username = user.get(SessionManagement.KEY_USER);

        if(username != null){
            return true;
        }
        else{
            return false;
        }
    }

    public void goToMain(){
        Intent intent = new Intent(_context, MainActivity.class);
        // Closing all the Activities
        intent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TASK);
        _context.startActivity(intent);
    }
}