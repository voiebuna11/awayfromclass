package com.example.afc;

import android.content.Context;
import android.content.DialogInterface;
import android.os.Bundle;
import android.support.design.widget.NavigationView;
import android.support.v4.widget.DrawerLayout;
import android.support.v7.app.ActionBarDrawerToggle;
import android.support.v7.app.AlertDialog;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.Toolbar;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.ImageView;
import android.widget.RelativeLayout;
import android.widget.TextView;
import android.widget.Toast;

import com.android.volley.RequestQueue;
import com.android.volley.toolbox.Volley;
import com.bumptech.glide.Glide;
import com.bumptech.glide.request.RequestOptions;
import com.example.afc.classes.SessionManagement;

import java.util.HashMap;

/* This is a Base Activity. Includes features used by multiple activies across the APP */

public abstract class BaseActivity extends AppCompatActivity {
    SessionManagement session;
    HashMap<String, String> sessionData;
    RequestQueue mQueue;

    Toolbar toolbar;
    ActionBarDrawerToggle toggleBtn;
    DrawerLayout drawerLayout;
    NavigationView nv;

    RelativeLayout progressCircle;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        //check session(if user is logged in)
        session = new SessionManagement(getApplicationContext());
        session.checkLogin();
        sessionData = session.getUserDetails();

        //setup activity layout elements
        setContentView(getLayoutResource());
        configureToolbar();
        configureSideMenu();
        configureSideMenuHeader();

        startLoadingBar();
        mQueue =  Volley.newRequestQueue(getApplicationContext());
    }
    protected abstract int getLayoutResource();

    //Top menu intialization
    private void configureToolbar() {
        toolbar = (Toolbar) findViewById(R.id.top_menu_layout);
        if (toolbar != null) {
            setSupportActionBar(toolbar);
            getSupportActionBar().setDisplayHomeAsUpEnabled(true);
        }
    }

    //Side menu initialization
    private void configureSideMenu(){
        nv = (NavigationView) findViewById(R.id.side_menu);
        drawerLayout = (DrawerLayout) findViewById(R.id.drawerLayout);

        toggleBtn = new ActionBarDrawerToggle(this, drawerLayout, R.string.sidemenu_open, R.string.sidemenu_close);
        drawerLayout.addDrawerListener(toggleBtn);
        toggleBtn.syncState();

        //setare butoane meniu lateral
        nv.setNavigationItemSelectedListener(new NavigationView.OnNavigationItemSelectedListener() {
            @Override
            public boolean onNavigationItemSelected(MenuItem menuItem) {
                switch (menuItem.getItemId()) {
                    case(R.id.nav_test):
                        return true;
                    case(R.id.nav_logout):
                        session.logoutUser();
                        return true;
                }
                return true;
            }
        });
    }

    private void configureSideMenuHeader(){
        final Context context = getApplicationContext();
        View header = nv.getHeaderView(0);

        final ImageView imageView = (ImageView) header.findViewById(R.id.menu_header_avatar);
        TextView mName = (TextView) header.findViewById(R.id.menu_header_name);
        TextView mEmail = (TextView) header.findViewById(R.id.menu_header_email);

        String url = "https://cdn.pixabay.com/photo/2017/07/18/23/23/user-2517433_960_720.png";

        mName.setText(sessionData.get("us_last_name") + " " + sessionData.get("us_first_name"));
        mEmail.setText(sessionData.get("us_email"));

        Glide.with(context)
                .load(url)
                .apply(RequestOptions.circleCropTransform())
                .into(imageView);
    }

    public void startLoadingBar(){
        progressCircle = (RelativeLayout) findViewById(R.id.progress_rl);
        progressCircle.setVisibility(View.VISIBLE);
    }

    public void stopLoadingBar(){
        progressCircle.setVisibility(View.GONE);
    }

    public void alert(String text){
        Toast.makeText(getApplicationContext(), text, Toast.LENGTH_LONG).show();
    }

    public void popUp(final Context context, String title, String message, String button) {
        final AlertDialog.Builder dialog = new AlertDialog.Builder(context);
        dialog.setTitle(title);
        dialog.setMessage(message);
        dialog.setPositiveButton(button, new DialogInterface.OnClickListener() {
            public void onClick(DialogInterface dialog, int which) {
                dialog.dismiss();
            }
        });
        dialog.show();
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        // Inflate the menu; this adds items to the action bar if it is present.
        getMenuInflater().inflate(R.menu.top_menu, menu);
        return true;
    }
    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        if(toggleBtn.onOptionsItemSelected(item)){
            return true;
        }
        switch (item.getItemId()) {
            case R.id.nav_mail: stopLoadingBar(); return true;
            default:
                return super.onOptionsItemSelected(item);
        }
    }
}
